package org.usfirst.frc.team3021.robot.commands.driving;

public class TurnRightToAngle45 extends TurnRightToAngle {
	
	public TurnRightToAngle45() {
		super(45.0);
	}
}
