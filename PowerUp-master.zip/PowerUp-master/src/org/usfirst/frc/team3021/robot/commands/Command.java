package org.usfirst.frc.team3021.robot.commands;

public abstract class Command extends edu.wpi.first.wpilibj.command.Command {

	public Command() {
		super();
	}

	@Override
	protected void initialize() {
	
	}

	@Override
	protected void execute() {
		
	}

	@Override
	protected boolean isFinished() {
		return true;
	}

	@Override
	protected void end() {
		
	}

	@Override
	protected void interrupted() {
		
	}

}