package org.usfirst.frc.team3021.robot.inputs;

public abstract class DriveInput {

}
