package org.usfirst.frc.team3021.robot.commands.system;

import org.usfirst.frc.team3021.robot.commands.Command;

public class SystemCommand extends Command {
	
	public SystemCommand() {
		super();
	}
	
	protected void execute() {
		
	}
	
	protected boolean isFinished() {
		return true;
	}
}
