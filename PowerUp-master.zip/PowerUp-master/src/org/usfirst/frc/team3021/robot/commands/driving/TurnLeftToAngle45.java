package org.usfirst.frc.team3021.robot.commands.driving;

public class TurnLeftToAngle45 extends TurnLeftToAngle {
	
	public TurnLeftToAngle45() {
		
		super(45.0);
	}
}
