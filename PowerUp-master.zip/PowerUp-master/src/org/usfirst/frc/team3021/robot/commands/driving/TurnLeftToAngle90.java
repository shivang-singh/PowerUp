package org.usfirst.frc.team3021.robot.commands.driving;

public class TurnLeftToAngle90 extends TurnLeftToAngle {
	
	public TurnLeftToAngle90() {
		super(90.0);
	}
}
