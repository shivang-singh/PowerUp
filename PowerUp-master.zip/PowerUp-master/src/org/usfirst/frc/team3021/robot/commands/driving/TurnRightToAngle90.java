package org.usfirst.frc.team3021.robot.commands.driving;

public class TurnRightToAngle90 extends TurnRightToAngle {
	
	public TurnRightToAngle90() {
		super(90.0);		
	}
}
