package org.usfirst.frc.team3021.robot.commands.driving;

public class TurnToAngle180 extends TurnToAngle {
	
	public TurnToAngle180() {
		super(180.0);
	}
}
