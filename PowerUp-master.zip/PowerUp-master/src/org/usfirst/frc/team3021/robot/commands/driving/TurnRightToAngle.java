package org.usfirst.frc.team3021.robot.commands.driving;

public class TurnRightToAngle extends TurnToAngle {

	public TurnRightToAngle(double desiredAngle) {
		super(desiredAngle);
	}

}
